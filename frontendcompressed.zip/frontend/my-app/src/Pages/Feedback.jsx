
import React from 'react';
import FeedbackCard from '../components/Feedbackcard';


const dummyFeedbacks = [
  { name: "Aarav", message: "This test really helped me decide!", date: "June 30, 2025" },
  { name: "Meera", message: "Very informative and quick.", date: "June 29, 2025" },
  { name: "Rahul", message: "Great UI, helpful insights.", date: "June 28, 2025" },
  { name: "Sneha", message: "Loved how simple the test was!", date: "June 27, 2025" },
  { name: "Dev", message: "Thanks for helping me choose science!", date: "June 26, 2025" },
];

const Feedback = () => {
  return (
    <div className="feedback-page-container">
      <h1>User Feedback</h1>
      <p>Here's what students are saying about Right Road:</p>
      <div className="feedback-list">
        {dummyFeedbacks.map((fb, index) => (
          <FeedbackCard key={index} feedback={fb} />
        ))}
      </div>
    </div>
  );
};

export default Feedback;
