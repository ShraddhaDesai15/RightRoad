import React from 'react';
import './FeedbackCard.css'; // Optional

const FeedbackCard = ({ feedback }) => {
  return (
    <div className="feedback-card">
      <h3>{feedback.name}</h3>
      <p>{feedback.message}</p>
      <span className="feedback-date">{feedback.date}</span>
    </div>
  );
};

export default FeedbackCard;
